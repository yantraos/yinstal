# yinstal
Package manager for LFS/BLFS

Use in conjuction with the yinstal build scripts here:
https://github.com/KeithDHedger/yinstalBuilds